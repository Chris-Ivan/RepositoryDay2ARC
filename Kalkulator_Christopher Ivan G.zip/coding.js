//FUNGSI
function update() {
  const display = document.querySelector(".screen");
  display.value = kalkulator.angka_layar;
}

function input_angka(digit) {
  const { angka_layar, wait_op2 } = kalkulator;

  if (wait_op2 === true) {
    kalkulator.angka_layar = digit;
    kalkulator.wait_op2 = false;}
  else {
    kalkulator.angka_layar = angka_layar === "0" ? digit : angka_layar + digit;}
}

function resetkalkulator() {
  kalkulator.angka_layar = "0";
  kalkulator.op1 = null;
  kalkulator.wait_op2 = false;
  kalkulator.operator = null;
}

function input_desimal(dot) {
	if (kalkulator.wait_op2 === true) return;
	if (!kalkulator.angka_layar.includes(dot)) {
    kalkulator.angka_layar += dot;}
}

function handle_operator(next_operator) {
  const { op1, angka_layar, operator } = kalkulator
  const inputValue = parseFloat(angka_layar);

  if (operator && kalkulator.wait_op2)  {
    kalkulator.operator = next_operator;
    return;}
  if (op1 == null) {
    kalkulator.op1 = inputValue;} 
  else if (operator) {
    const currentValue = op1 || 0;
    const result = hitung[operator](currentValue, inputValue);

    kalkulator.angka_layar = String(result);
    kalkulator.op1 = result;}

  kalkulator.wait_op2 = true;
  kalkulator.operator = next_operator;}


//ALGORITMA

const kalkulator = {
  angka_layar: "0",
  op1: null,
  wait_op2: false,
  operator: null,
};

const hitung = {
  "+": (op1, op2) => op1 + op2,
  "-": (op1, op2) => op1 - op2,
  "*": (op1, op2) => op1 * op2,
  "/": (op1, op2) => op1 / op2,
  "=": (op1, op2) => op2
};

update();

const keys = document.querySelector(".calculator");
keys.addEventListener("click", (event) => {
  const { target } = event;
  
  if (target.classList.contains("decimal")) {
    input_desimal(target.value);
		update();
    return;}
  if (target.classList.contains("clear-value")) {
    resetkalkulator();
		update();
    return;}
  if (!target.matches("button")) {
    return;}
  if (target.classList.contains("operator")) {
    handle_operator(target.value);
		update();
    return;}

  input_angka(target.value);
  update();
});